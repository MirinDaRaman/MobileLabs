package com.example.android.mobilecourse;

import android.app.Activity;

//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
public class MainActivity extends Activity {

}
